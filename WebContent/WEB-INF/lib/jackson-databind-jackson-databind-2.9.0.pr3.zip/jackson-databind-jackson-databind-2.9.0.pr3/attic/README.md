Place where formerly used code is moved if it seems possible (or perhaps even likely) it might
be reused at some point. Or, for some experimental code that isn't yet used.

